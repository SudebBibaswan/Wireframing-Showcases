import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  ArrowRight,
  Bell,
  Check,
  ChevronDown,
  CircleUserRound,
  Command,
  CreditCard,
  Menu,
  MessageSquare,
  Mic,
  Paperclip,
  Play,
  Save,
  Send,
  Settings,
  ShieldCheck,
  Smartphone,
  Sparkles,
  UserRound,
  Volume2,
  WandSparkles,
} from "lucide-react";
import { useRef, useState } from "react";
import type { ComponentType, ReactNode } from "react";

type WireframeScreen = {
  id: string;
  title: string;
  description: string;
  image: string;
  icon: ReactNode;
  features: string[];
};

type ChatMessage = {
  id: number;
  role: "user" | "assistant";
  text: string;
  time: string;
  pending?: boolean;
};

const wireframes: WireframeScreen[] = [
  {
    id: "home",
    title: "Home Screen",
    description:
      "The initial landing screen greets users with the ChatGPT logo and a welcoming prompt. Four quick-action cards provide immediate access to common tasks: Create image, Summarize text, Help me write, and Surprise me. A persistent input bar at the bottom enables seamless message composition.",
    image: "/manus-storage/chatgpt_wireframe_home_ea247e88.png",
    icon: <Smartphone className="w-6 h-6" />,
    features: ["Centered logo with welcoming prompt", "Quick-action cards for common tasks", "Persistent input bar for messaging", "Clean, minimal visual hierarchy"],
  },
  {
    id: "chat",
    title: "Chat Interface",
    description:
      "The chat screen displays an active conversation with the selected AI model. User messages appear right-aligned in light gray bubbles, while assistant responses are left-aligned with the ChatGPT icon. The header shows the current model with a dropdown selector, and a back button for navigation.",
    image: "/manus-storage/chatgpt_wireframe_chat_a80c1c0a.png",
    icon: <MessageSquare className="w-6 h-6" />,
    features: ["Model selector in header", "Distinct message bubble styling", "Scrollable conversation history", "Persistent input bar with send button"],
  },
  {
    id: "sidebar",
    title: "Navigation Sidebar",
    description:
      "The slide-out navigation drawer provides quick access to chat history and settings. A search bar at the top allows users to find previous conversations. Chat history is organized by time periods, while the bottom section displays user profile information and settings access.",
    image: "/manus-storage/chatgpt_wireframe_sidebar_9f380027.png",
    icon: <Menu className="w-6 h-6" />,
    features: ["Search history functionality", "Time-based chat organization", "Quick access to new chat", "User profile and settings"],
  },
];

const initialMessages: ChatMessage[] = [
  { id: 1, role: "user", text: "How can I understand my data better?", time: "10:42 AM" },
  { id: 2, role: "assistant", text: "Start by looking for patterns, outliers, and changes over time. I can help turn those signals into a clear story.", time: "10:42 AM" },
];

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: () => void; label: string }) {
  return (
    <button type="button" aria-label={label} aria-pressed={checked} onClick={onChange} className={`relative h-6 w-11 rounded-full transition-colors ${checked ? "bg-blue-600" : "bg-gray-300"}`}>
      <span className={`absolute top-1 h-4 w-4 rounded-full bg-white shadow-sm transition-transform ${checked ? "translate-x-6" : "translate-x-1"}`} />
    </button>
  );
}

export default function Home() {
  const [expandedId, setExpandedId] = useState<string | null>("home");
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [draft, setDraft] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [profileTab, setProfileTab] = useState<"profile" | "settings">("profile");
  const [notifications, setNotifications] = useState(true);
  const [memory, setMemory] = useState(true);
  const messageId = useRef(10);

  const sendMessage = (value = draft) => {
    const text = value.trim();
    if (!text || isTyping) return;
    const userMessage: ChatMessage = { id: messageId.current++, role: "user", text, time: "now" };
    setMessages((current) => [...current, userMessage]);
    setDraft("");
    setIsTyping(true);
    window.setTimeout(() => {
      setMessages((current) => [...current, { id: messageId.current++, role: "assistant", text: "I’m on it — here’s a clearer way to explore that idea with ChatGPT.", time: "now" }]);
      setIsTyping(false);
    }, 900);
  };

  const toggleListening = () => {
    setIsListening((value) => !value);
    if (!isListening) window.setTimeout(() => setIsListening(false), 3600);
  };

  return (
    <div className="min-h-screen bg-white">
      <header className="sticky top-0 z-50 bg-white/85 backdrop-blur-sm border-b border-gray-200">
        <div className="container py-5 flex items-center justify-between">
          <a href="#top" className="flex items-center gap-3" aria-label="ChatGPT Mobile home">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center shadow-sm"><span className="text-white font-bold text-lg">C</span></div>
            <div><h1 className="text-2xl font-bold text-gray-900">ChatGPT Mobile</h1><p className="text-sm text-gray-600">Wireframe Showcase</p></div>
          </a>
          <nav className="hidden md:flex gap-7 text-sm" aria-label="Page sections">
            <a href="#home" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">Screens</a>
            <a href="#prototype" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">Prototype lab</a>
            <a href="#profile" className="text-gray-700 hover:text-blue-600 transition-colors font-medium">Profile & settings</a>
          </nav>
        </div>
      </header>

      <main id="top">
        <section className="container py-16 md:py-24">
          <div className="max-w-3xl">
            <div className="eyebrow mb-5"><Sparkles className="w-4 h-4" /> Interaction-ready mobile system</div>
            <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">Explore the ChatGPT Mobile Interface</h2>
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">A comprehensive wireframe showcase for a calm, capable mobile assistant. Review the core screens, then try the interaction patterns: live message exchange, voice input, and a profile/settings surface built for control.</p>
            <div className="flex flex-wrap gap-3">
              <a href="#prototype"><Button className="bg-blue-600 hover:bg-blue-700 text-white">Try the prototype <ArrowRight className="w-4 h-4 ml-2" /></Button></a>
              <a href="#profile"><Button variant="outline" className="border-gray-300">Open profile settings <UserRound className="w-4 h-4 ml-2" /></Button></a>
            </div>
          </div>
        </section>

        <section id="home" className="bg-gray-50 py-16 md:py-24">
          <div className="container">
            <div className="mb-14"><h3 className="text-3xl font-bold text-gray-900 mb-4">Key Screens</h3><div className="section-divider" /></div>
            <div className="space-y-16">
              {wireframes.map((screen, index) => (
                <div key={screen.id} id={screen.id} className="grid md:grid-cols-2 gap-12 items-center">
                  <div className={`${index % 2 === 1 ? "md:order-2" : ""} space-y-6`}>
                    <div className="flex items-center gap-3"><div className="p-3 bg-blue-100 rounded-xl text-blue-600">{screen.icon}</div><h4 className="text-2xl font-bold text-gray-900">{screen.title}</h4></div>
                    <p className="text-gray-700 leading-relaxed">{screen.description}</p>
                    <div className="space-y-3"><h5 className="font-semibold text-gray-900">Key Features:</h5><ul className="space-y-2">{screen.features.map((feature) => <li key={feature} className="flex items-start gap-3 text-gray-700"><span className="inline-block w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0" /><span>{feature}</span></li>)}</ul></div>
                    <Button variant="outline" className="border-gray-300 text-gray-900 hover:bg-gray-100" onClick={() => setExpandedId(expandedId === screen.id ? null : screen.id)}>{expandedId === screen.id ? "Hide details" : "View details"}</Button>
                    {expandedId === screen.id && <div className="detail-note"><Check className="w-4 h-4 text-blue-600 mt-0.5" /><span>Designed as a reusable mobile pattern with clear hierarchy, progressive disclosure, and an escape route on every surface.</span></div>}
                  </div>
                  <div className={`${index % 2 === 1 ? "md:order-1" : ""} flex justify-center`}><div className="glass-card p-4 w-full max-w-sm"><div className="wireframe-container aspect-[9/16]"><img src={screen.image} alt={screen.title} className="w-full h-full object-cover" /></div></div></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="prototype" className="container py-16 md:py-24">
          <div className="flex flex-wrap items-end justify-between gap-6 mb-10"><div><div className="eyebrow mb-4"><Play className="w-4 h-4" /> Clickable prototype</div><h3 className="text-3xl font-bold text-gray-900 mb-3">A chat that feels alive</h3><p className="text-gray-600 max-w-2xl">Test the send flow in place. Messages arrive with a lightweight reveal, the assistant responds after a natural pause, and the voice control exposes a listening state without leaving the conversation.</p></div><div className="flex items-center gap-2 text-sm text-gray-500"><span className="status-dot" /> Live interaction demo</div></div>
          <Card className="prototype-shell overflow-hidden border-gray-200 shadow-xl">
            <div className="grid lg:grid-cols-[1fr_280px]">
              <div className="bg-[#fbfbfc] min-h-[580px] flex flex-col">
                <div className="px-5 py-4 border-b border-gray-200 bg-white/80 flex items-center justify-between"><div className="flex items-center gap-3"><div className="w-9 h-9 rounded-full bg-gray-900 text-white flex items-center justify-center"><Command className="w-4 h-4" /></div><div><p className="font-semibold text-gray-900">Data exploration</p><p className="text-xs text-gray-500">ChatGPT 4o <ChevronDown className="inline w-3 h-3" /></p></div></div><button type="button" className="icon-button" aria-label="Conversation settings"><Settings className="w-4 h-4" /></button></div>
                <div className="flex-1 p-5 space-y-5 overflow-auto max-h-[405px]">{messages.map((message) => <div key={message.id} className={`message-row ${message.role === "user" ? "justify-end" : "justify-start"}`}><div className={`max-w-[78%] ${message.role === "user" ? "message-user" : "message-assistant"}`}><div className="flex items-start gap-2">{message.role === "assistant" && <div className="mt-0.5 w-6 h-6 rounded-full bg-gray-900 text-white flex items-center justify-center flex-shrink-0"><Sparkles className="w-3 h-3" /></div>}<div><p className="text-sm leading-relaxed">{message.text}</p><span className="message-time">{message.time}</span></div></div></div></div>)}{isTyping && <div className="message-row justify-start"><div className="message-assistant"><div className="flex items-center gap-2"><div className="w-6 h-6 rounded-full bg-gray-900 text-white flex items-center justify-center"><Sparkles className="w-3 h-3" /></div><div className="typing-dots"><i /><i /><i /></div><span className="text-xs text-gray-500">Thinking</span></div></div></div>}</div>
                <div className="p-4 bg-white border-t border-gray-200"><div className={`chat-input ${isListening ? "listening" : ""}`}><button type="button" className="input-icon" aria-label="Attach file"><Paperclip className="w-4 h-4" /></button><input aria-label="Message ChatGPT" value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") sendMessage(); }} placeholder={isListening ? "Listening…" : "Message ChatGPT"} /><button type="button" onClick={toggleListening} aria-label={isListening ? "Stop voice input" : "Start voice input"} className={`voice-button ${isListening ? "voice-active" : ""}`}><Mic className="w-4 h-4" />{isListening && <span className="voice-bars"><i /><i /><i /><i /></span>}</button><button type="button" onClick={() => sendMessage()} aria-label="Send message" className="send-button"><Send className="w-4 h-4" /></button></div><p className="text-[11px] text-gray-400 mt-2 text-center">ChatGPT can make mistakes. Check important info.</p></div>
              </div>
              <aside className="bg-gray-900 text-white p-6 flex flex-col justify-between"><div><p className="text-xs uppercase tracking-[0.18em] text-blue-300 mb-4">Interaction notes</p><h4 className="text-xl font-semibold mb-5">Small moments, clear feedback.</h4><div className="space-y-5">{[["01", "Send", "User bubble enters immediately; response follows after a short thinking state."], ["02", "Receive", "Assistant content uses a distinct rhythm and identity marker."], ["03", "Voice", "The mic becomes a listening surface with animated level bars."]].map(([number, title, text]) => <div key={number} className="flex gap-3"><span className="text-xs text-blue-300 pt-1">{number}</span><div><p className="font-medium mb-1">{title}</p><p className="text-sm text-gray-400 leading-relaxed">{text}</p></div></div>)}</div></div><div className="pt-8 mt-8 border-t border-white/10"><div className="flex items-center gap-2 text-sm text-gray-300"><Volume2 className="w-4 h-4 text-blue-300" /> Voice-ready interaction</div></div></aside>
            </div>
          </Card>
        </section>

        <section id="profile" className="bg-gray-50 py-16 md:py-24">
          <div className="container"><div className="max-w-2xl mb-10"><div className="eyebrow mb-4"><CircleUserRound className="w-4 h-4" /> Account surface</div><h3 className="text-3xl font-bold text-gray-900 mb-3">Profile & settings</h3><p className="text-gray-600">A friendly account surface keeps personalization visible while giving users control over notifications, memory, privacy, and plan details.</p></div>
            <Card className="profile-card overflow-hidden border-gray-200 shadow-lg"><div className="grid lg:grid-cols-[250px_1fr]"><div className="profile-rail p-5 border-b lg:border-b-0 lg:border-r border-gray-200"><div className="flex items-center gap-3 p-3 mb-5"><div className="w-11 h-11 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 text-white flex items-center justify-center font-semibold">AR</div><div><p className="font-semibold text-gray-900">Alex Rivera</p><p className="text-xs text-gray-500">Free plan</p></div></div><div className="space-y-1"><button type="button" onClick={() => setProfileTab("profile")} className={`profile-tab ${profileTab === "profile" ? "active" : ""}`}><UserRound className="w-4 h-4" /> Profile</button><button type="button" onClick={() => setProfileTab("settings")} className={`profile-tab ${profileTab === "settings" ? "active" : ""}`}><Settings className="w-4 h-4" /> Settings</button></div><div className="mt-8 rounded-xl bg-blue-50 p-4"><ShieldCheck className="w-5 h-5 text-blue-600 mb-3" /><p className="text-sm font-medium text-gray-900 mb-1">Your data, your control</p><p className="text-xs leading-relaxed text-gray-600">Privacy choices stay close, understandable, and reversible.</p></div></div>
              <div className="p-6 md:p-8">{profileTab === "profile" ? <div className="space-y-7"><div className="flex items-start justify-between gap-4"><div><p className="text-sm text-gray-500 mb-1">Personal profile</p><h4 className="text-2xl font-bold text-gray-900">Make ChatGPT yours</h4></div><Button variant="outline" className="border-gray-300"><Save className="w-4 h-4 mr-2" /> Save</Button></div><div className="grid md:grid-cols-2 gap-5"><label className="field-label">Display name<input defaultValue="Alex Rivera" /></label><label className="field-label">Email address<input defaultValue="alex@example.com" /></label></div><label className="field-label">Personalization instructions<textarea defaultValue="Keep answers clear, practical, and concise." rows={3} /></label><div className="rounded-xl border border-gray-200 p-4 flex items-center justify-between gap-4"><div className="flex gap-3"><WandSparkles className="w-5 h-5 text-blue-600 mt-0.5" /><div><p className="font-medium text-gray-900">Personalized responses</p><p className="text-sm text-gray-500">Use your preferences to make answers more relevant.</p></div></div><Toggle label="Toggle personalized responses" checked={memory} onChange={() => setMemory(!memory)} /></div></div> : <div className="space-y-5"><div><p className="text-sm text-gray-500 mb-1">Preferences</p><h4 className="text-2xl font-bold text-gray-900">Settings that stay simple</h4></div>{[[Bell, "Notifications", "Product updates and helpful reminders", notifications, () => setNotifications(!notifications)], [Sparkles, "Memory", "Let ChatGPT remember useful preferences", memory, () => setMemory(!memory)]].map(([Icon, title, text, checked, onChange]) => { const SettingIcon = Icon as ComponentType<{ className?: string }>; return <div key={title as string} className="setting-row"><div className="flex gap-3"><div className="setting-icon"><SettingIcon className="w-4 h-4" /></div><div><p className="font-medium text-gray-900">{title as string}</p><p className="text-sm text-gray-500">{text as string}</p></div></div><Toggle label={`Toggle ${title as string}`} checked={checked as boolean} onChange={onChange as () => void} /></div>; })}<div className="setting-row"><div className="flex gap-3"><div className="setting-icon"><CreditCard className="w-4 h-4" /></div><div><p className="font-medium text-gray-900">Plan & billing</p><p className="text-sm text-gray-500">Free plan · Manage your subscription</p></div></div><ChevronDown className="w-4 h-4 text-gray-400 -rotate-90" /></div></div>}</div>
            </div></Card>
          </div>
        </section>

        <section className="container py-16 md:py-24"><h3 className="text-3xl font-bold text-gray-900 mb-4">Design Principles</h3><div className="section-divider mb-12" /><div className="grid md:grid-cols-3 gap-6">{[["Clarity & focus", "Every element serves a purpose; content and functionality lead."], ["Explore intuitively", "Quick actions, sensible grouping, and readable feedback help users explore data without friction."], ["Understand trends", "Conversation, memory, and visual hierarchy turn complex signals into a story."], ["Save or share", "Persistent history and clear account controls make it easy to keep work moving."], ["Accessibility", "High contrast, readable typography, and clear interaction patterns support everyone."], ["Responsive by default", "The system adapts across screen sizes while keeping core actions close."]].map(([title, description]) => <Card key={title} className="p-6 border-gray-200 hover:shadow-lg transition-shadow"><h4 className="font-bold text-gray-900 mb-3">{title}</h4><p className="text-gray-700 text-sm leading-relaxed">{description}</p></Card>)}</div></section>
      </main>

      <footer className="bg-gray-900 text-gray-300 py-12"><div className="container"><div className="grid md:grid-cols-4 gap-8 mb-8"><div><h5 className="font-bold text-white mb-4">About</h5><p className="text-sm leading-relaxed">A mobile wireframe system for ChatGPT that makes key screens and interaction states easy to review.</p></div><div><h5 className="font-bold text-white mb-4">Prototype</h5><p className="text-sm leading-relaxed">Try live messaging, voice input, and editable profile settings above.</p></div><div><h5 className="font-bold text-white mb-4">Focus</h5><p className="text-sm leading-relaxed">Explore data intuitively, understand trends better, and easily save or share.</p></div><div><h5 className="font-bold text-white mb-4">Status</h5><p className="text-sm leading-relaxed flex items-center gap-2"><span className="status-dot status-dot-dark" /> Interaction-ready</p></div></div><div className="border-t border-gray-800 pt-8"><p className="text-center text-sm">© 2025 ChatGPT Mobile Wireframe Showcase. All rights reserved.</p></div></div></footer>
    </div>
  );
}
